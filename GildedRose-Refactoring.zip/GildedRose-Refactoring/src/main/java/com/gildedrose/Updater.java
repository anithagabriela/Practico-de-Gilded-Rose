package com.gildedrose;

public interface Updater {

	public void update(Item item);
	
}
