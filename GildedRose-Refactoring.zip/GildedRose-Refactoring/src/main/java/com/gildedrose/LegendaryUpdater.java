package com.gildedrose;

public class LegendaryUpdater implements Updater {

	public void update(Item item) {
	}

}
